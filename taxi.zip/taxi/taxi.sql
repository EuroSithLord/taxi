-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Окт 09 2012 г., 14:45
-- Версия сервера: 5.5.27
-- Версия PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `taxi`
--

-- --------------------------------------------------------

--
-- Структура таблицы `firme`
--

CREATE TABLE IF NOT EXISTS `firme` (
  `ID_FIRMA` int(4) NOT NULL DEFAULT '0',
  `NUME_FIRMA` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ID_FIRMA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `frecventa`
--

CREATE TABLE IF NOT EXISTS `frecventa` (
  `ID_SOFER` int(11) NOT NULL,
  `DATA` date NOT NULL,
  `PRESENT` tinyint(4) DEFAULT '1',
  `CAUZA_ABS` varchar(30) DEFAULT '',
  `INCOME` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `masina`
--

CREATE TABLE IF NOT EXISTS `masina` (
  `ID_MASINA` int(4) NOT NULL AUTO_INCREMENT,
  `NR` varchar(10) NOT NULL,
  `MODEL` varchar(20) NOT NULL,
  `OWNER` varchar(20) NOT NULL,
  `SOFER_1` int(11) DEFAULT NULL,
  `SOFER_2` int(11) DEFAULT NULL,
  `REVIZIA_TEHNICA` date DEFAULT NULL,
  `URMATORUL_CONTROL` date DEFAULT NULL,
  PRIMARY KEY (`ID_MASINA`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `masina`
--

INSERT INTO `masina` (`ID_MASINA`, `NR`, `MODEL`, `OWNER`, `SOFER_1`, `SOFER_2`, `REVIZIA_TEHNICA`, `URMATORUL_CONTROL`) VALUES
(1, 'CPW 795', 'Dacia Logan', 'BSC', 0, 0, '2012-10-09', '2013-04-09'),
(2, 'CPQ 806', 'Dacia Logan', 'BSC', 0, 0, '2012-10-09', '2013-04-09'),
(3, 'KAE 584', 'Dacia Logan', 'BSC', 0, 0, '2012-10-09', '2013-04-09'),
(4, 'CXX 711', 'Dacia Logan', 'BSC', 0, 0, '2012-10-09', '2013-04-09'),
(5, 'COY 950', 'Dacia Logan', 'BSC', 0, 0, '2012-10-09', '2013-04-09');

-- --------------------------------------------------------

--
-- Структура таблицы `piese`
--

CREATE TABLE IF NOT EXISTS `piese` (
  `ID_PIESA` int(4) NOT NULL AUTO_INCREMENT,
  `DENUMIREA` varchar(30) NOT NULL,
  `U/M` varchar(5) NOT NULL,
  `PRET` float NOT NULL,
  `CANTITATE` int(5) NOT NULL,
  `SUMA` float NOT NULL,
  `DATA` date NOT NULL,
  PRIMARY KEY (`ID_PIESA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `planning`
--

CREATE TABLE IF NOT EXISTS `planning` (
  `DATA` date NOT NULL,
  `ID_SOFER` int(4) NOT NULL,
  `ID_MASINA` int(4) NOT NULL,
  `PLAN` int(5) DEFAULT '0',
  `CASH` int(5) DEFAULT '0',
  `AMENDA` int(3) DEFAULT '0',
  `BONUS` int(3) DEFAULT '0',
  `PERSONAL` int(3) DEFAULT '0',
  `REPARATIE` int(5) DEFAULT '0',
  `GPS` int(2) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `planning`
--

INSERT INTO `planning` (`DATA`, `ID_SOFER`, `ID_MASINA`, `PLAN`, `CASH`, `AMENDA`, `BONUS`, `PERSONAL`, `REPARATIE`, `GPS`) VALUES
('2012-10-09', 0, 1, 335, 335, 0, 0, 0, 0, 5),
('2012-10-09', 1, 2, 0, 0, 0, 0, 0, 0, 0),
('2012-10-09', 5, 4, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `reparatii`
--

CREATE TABLE IF NOT EXISTS `reparatii` (
  `DATA` date NOT NULL,
  `ID_MASINA` int(4) NOT NULL,
  `ID_PIESA` int(4) NOT NULL,
  `KM_PARCURSI` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `revizia_tehnica`
--

CREATE TABLE IF NOT EXISTS `revizia_tehnica` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MASINA` int(4) NOT NULL,
  `DATA_CONTROL` date NOT NULL,
  `URMATORUL_CONTROL` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `schimb_ulei`
--

CREATE TABLE IF NOT EXISTS `schimb_ulei` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_MASINA` int(4) NOT NULL,
  `DATA_SCHIMB` date NOT NULL,
  `INDICATII_ACTUALE` varchar(7) NOT NULL,
  `KM_PARCURSI` varchar(7) NOT NULL,
  `KM_PINA_LA_SCHIMB` varchar(7) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `soferi`
--

CREATE TABLE IF NOT EXISTS `soferi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_SOFER` int(11) NOT NULL,
  `NUME` varchar(20) NOT NULL,
  `PRENUME` varchar(20) NOT NULL,
  `DATA_NASTERII` date DEFAULT NULL,
  `ID_MASINA` int(11) NOT NULL,
  `ADRESA` varchar(50) DEFAULT NULL,
  `TELEFON_1` varchar(10) NOT NULL,
  `TELEFON_2` varchar(10) DEFAULT NULL,
  `TELEFON_3` varchar(10) DEFAULT NULL,
  `FOTO` varchar(20) DEFAULT NULL,
  `CONTRACT` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID_SOFER` (`ID_SOFER`),
  KEY `ID_MASINA` (`ID_MASINA`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `soferi`
--

INSERT INTO `soferi` (`ID`, `ID_SOFER`, `NUME`, `PRENUME`, `DATA_NASTERII`, `ID_MASINA`, `ADRESA`, `TELEFON_1`, `TELEFON_2`, `TELEFON_3`, `FOTO`, `CONTRACT`) VALUES
(1, 0, 'Lungu', 'Mihail', '1951-05-10', 1, 'Chisinau, str. Iazului 2/2, ap. 30', '069181544', '022549060', '', NULL, NULL),
(2, 1, 'Martaloc', 'Valentin', '1981-06-13', 2, 'Chisinau, str. Mihail Sadoveanu 22/2, ap. 95', '069459362', '', '', NULL, NULL),
(3, 5, 'Lungu', 'Serghei', '1976-12-19', 4, 'Ungheni, s. Hircesti', '069574188', '', '', NULL, NULL),
(4, 4, 'Ciuciulean', 'Luca', '1968-04-09', 5, 'Chisinau, com. Ciorescu, str. Prieteniei 37', '079025404', '', '', NULL, NULL),
(5, 2, 'Bernstein', 'Dmitri', '1983-09-02', 3, 'Chisinau, str. Minsc 45, ap. 57', '079214338', '068360710', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_in`
--

CREATE TABLE IF NOT EXISTS `ticket_in` (
  `ID_TICKET` int(4) NOT NULL AUTO_INCREMENT,
  `DATA_IN` date NOT NULL,
  `VALOARE` int(2) NOT NULL,
  `SERIA_NR` varchar(15) NOT NULL,
  PRIMARY KEY (`ID_TICKET`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_out`
--

CREATE TABLE IF NOT EXISTS `ticket_out` (
  `ID_TICKET` int(4) NOT NULL AUTO_INCREMENT,
  `DATA` date NOT NULL,
  `VALOARE` int(2) NOT NULL,
  `SERIA_NR` varchar(15) NOT NULL,
  `ID_FIRMA` int(4) NOT NULL,
  PRIMARY KEY (`ID_TICKET`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_sofer_0`
--

CREATE TABLE IF NOT EXISTS `ticket_sofer_0` (
  `DATA` date DEFAULT NULL,
  `TICKET` varchar(30) DEFAULT NULL,
  `VALOARE` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_sofer_1`
--

CREATE TABLE IF NOT EXISTS `ticket_sofer_1` (
  `DATA` date DEFAULT NULL,
  `TICKET` varchar(30) DEFAULT NULL,
  `VALOARE` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_sofer_2`
--

CREATE TABLE IF NOT EXISTS `ticket_sofer_2` (
  `DATA` date DEFAULT NULL,
  `TICKET` varchar(30) DEFAULT NULL,
  `VALOARE` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_sofer_4`
--

CREATE TABLE IF NOT EXISTS `ticket_sofer_4` (
  `DATA` date DEFAULT NULL,
  `TICKET` varchar(30) DEFAULT NULL,
  `VALOARE` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_sofer_5`
--

CREATE TABLE IF NOT EXISTS `ticket_sofer_5` (
  `DATA` date DEFAULT NULL,
  `TICKET` varchar(30) DEFAULT NULL,
  `VALOARE` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_sofer_457`
--

CREATE TABLE IF NOT EXISTS `ticket_sofer_457` (
  `DATA` date DEFAULT NULL,
  `TICKET` varchar(30) DEFAULT NULL,
  `VALOARE` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `ticket_used`
--

CREATE TABLE IF NOT EXISTS `ticket_used` (
  `ID_TICKET` int(4) NOT NULL AUTO_INCREMENT,
  `VALOARE` int(2) NOT NULL,
  `SERIA_NR` varchar(15) NOT NULL,
  `DATA_OUT` date NOT NULL,
  `DATA_USED` date NOT NULL,
  `ID_SOFER` int(4) NOT NULL,
  PRIMARY KEY (`ID_TICKET`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
