function edit(content,control,thumbs,id) {
	
	var control = document.getElementById(control);
	
	control.innerHTML = "<input type=\"submit\" id=\"edit\" value=\"Confirma modificarea\" onmousedown=\"document.getElementById('editFormSoferi').action += document.getElementById('idSofer').value\" /> " +
			"<a href='StergeSofer?id=<%=id%>'><input type='button' value='Sterge sofer' disabled/></a>";
	
	var thumbs = document.getElementById(thumbs) 
	
	document.getElementById("selectMasini").disabled = false;
	
	thumbs.innerHTML += "<br>Foto: <input type='file' name='file'/><br>Contract: <input type='file' name='file'/>";
	thumbs.style.paddingRight = 0;
	thumbs.style.marginRight = "-10px";
	
	var input = document.getElementsByTagName("input");
	for (var i = 0 ; i < input.length; i++) 
		if ( input[i].type == "text") {
			input[i].readOnly = false;
			input[i].style.border = "1px";
			input[i].style.backgroundColor = "white";
		}
	
	var content = document.getElementById(content);
	content.innerHTML = "<form action='EditSofer?id=" + id + "&idSofer=' method='POST' enctype='multipart/form-data' id='editFormSoferi'>" + content.innerHTML + "</form>";
}

function openAddForm(page) {
	var width;
	var height;

	width = (window.screen.width/2) -200;
	height = (window.screen.height/2) - 400;

	var popUpWin = window.open(page,"Adauga Sofer","status=no,height=800,width=400," +
			"resizable=no,left=" + width + ",top=" + height + ",screenX=" + width + ",screenY=" + height + "," +
			"toolbar=no,menubar=no,scrollbars=no,location=no,directories=no,status=no"
	);
	
	popUpWin.focus();
}

function activateButton(idButton, idLink, idArg) {
	document.getElementById(idButton).disabled = false;
	var link = document.getElementById(idLink);
	link.href += document.getElementById(idArg).innerHTML;
}


function openWindowTicket(url) {
	window.open("include/addForm/" + url, "AddForm", "status = 0, height = 300, width = 300, resizable = 0" );
}


function loadContent(adrr, id, val){
	
	xmlhttp=GetXmlHttpObject();

	if (xmlhttp==null) {
		alert ("Your browser does not support Ajax HTTP");
		return;
	}
    
	xmlhttp.open("GET","/14300/"+ adrr +"?id="+id+"&val="+val,true);
	xmlhttp.send(null);
	
}

function updateFrecventa(sof, data, col, val) {
	xmlhttp=GetXmlHttpObject();

	if (xmlhttp==null) {
		alert ("Your browser does not support Ajax HTTP");
		return;
	}
	xmlhttp.open("GET","UpdateFrecventa?idSofer="+sof+"&data="+data+"&col="+col+"&val="+val,true);
	xmlhttp.send(null);
}

function updatePlanning(sof, data, col, val) {
	xmlhttp=GetXmlHttpObject();

	if (xmlhttp==null) {
		alert ("Your browser does not support Ajax HTTP");
		return;
	}
	xmlhttp.open("GET","UpdatePlanning?idSofer="+sof+"&data="+data+"&col="+col+"&val="+val,true);
	xmlhttp.send(null);
}

function GetXmlHttpObject(){
   if (window.XMLHttpRequest) {
	   return new XMLHttpRequest();
   }
   if (window.ActiveXObject) {
	   return new ActiveXObject("Microsoft.XMLHTTP");
   }
   return null;
}

function addTicket(tag,sofer,data) {
	tag.parentNode.innerHTML = "<input onblur=\"updatePlanning('"+sofer+"','"+data+"', 'Ticket', this.value); this.style.border = '0px'; this.style.backgroundColor = '#DADADA'; \" type=\"text\" " +
			"onclick=\"this.style.border = '1px'; this.style.backgroundColor = 'white'\" />" + tag.parentNode.innerHTML;
								
}


